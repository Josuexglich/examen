package tareas;

public class App2 {

	    public static void main(String[] args) {
	        Telefono telefono = new Telefono("Samsung", "A15", 250.0);

	        System.out.println("=== Datos iniciales ===");
	        telefono.mostrarInfo();

	        System.out.println();
	        System.out.println("=== Cambiando datos con setters ===");
	        telefono.setModelo("A16");
	        telefono.setPrecio(300.0);   // cambio válido
	        telefono.setPrecio(-50.0);   // cambio inválido (no debe aplicarse)
	        telefono.mostrarInfo();

	        System.out.println();
	        System.out.println("Precio actual (getter): $" + telefono.getPrecio());
	    }
	

}
