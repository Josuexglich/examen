		
		import java.util.ArrayList;

		public class Refugio {

		    private ArrayList<Animal> animales;

		    public Refugio() {
		        this.animales = new ArrayList<>();
		    }

		    public boolean estaVacio() {
		        return animales.isEmpty();
		    }

		    // Devuelve false si el animal es nulo o el ID ya existe
		    public boolean registrarAnimal(Animal animal) {
		        if (animal == null) {
		            return false;
		        }
		        if (buscarPorId(animal.getId()) != null) {
		            return false;
		        }
		        animales.add(animal);
		        return true;
		    }

		    // Búsqueda secuencial: devuelve la primera coincidencia o null
		    public Animal buscarPorId(int id) {
		        for (Animal a : animales) {
		            if (a.getId() == id) {
		                return a;
		            }
		        }
		        return null;
		    }

		    public void mostrarAnimales() {
		        if (animales.isEmpty()) {
		            System.out.println("No hay animales registrados en el refugio.");
		            return;
		        }
		        for (Animal a : animales) {
		            System.out.println("-----------------------------");
		            a.mostrarInformacion();
		            System.out.println("Acción: " + a.realizarAccion()); // polimorfismo
		        }
		        System.out.println("-----------------------------");
		    }

		    // Devuelve true solo si existía y estaba DISPONIBLE
		    public boolean adoptarAnimal(int id) {
		        Animal a = buscarPorId(id);
		        if (a == null || a.getEstado().equals("ADOPTADO")) {
		            return false;
		        }
		        a.setEstado("ADOPTADO");
		        return true;
		    }
		
		

	}


