import java.util.Scanner;

public class Main {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Refugio refugio = new Refugio();
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    registrarAnimal(refugio);
                    break;
                case 2:
                    refugio.mostrarAnimales();
                    break;
                case 3:
                    buscarAnimal(refugio);
                    break;
                case 4:
                    adoptarAnimal(refugio);
                    break;
                case 5:
                    System.out.println("Saliendo del sistema. ¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción inválida. Elija un valor entre 1 y 5.");
            }
        } while (opcion != 5);

        sc.close();
    }

    private static void mostrarMenu() {
        System.out.println();
        System.out.println("=========== REFUGIO ===========");
        System.out.println("1. Registrar animal");
        System.out.println("2. Mostrar animales");
        System.out.println("3. Buscar animal por ID");
        System.out.println("4. Adoptar animal");
        System.out.println("5. Salir");
    }

    // Lee un entero; si la entrada no es numérica informa el error y vuelve a pedir
    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un número entero válido.");
            }
        }
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine().trim();
    }

    private static void registrarAnimal(Refugio refugio) {
        int tipo = leerEntero("Tipo de animal (1 = Perro, 2 = Gato): ");
        if (tipo != 1 && tipo != 2) {
            System.out.println("Tipo inválido. Solo se acepta 1 o 2.");
            return;
        }

        int id = leerEntero("ID: ");
        if (id <= 0) {
            System.out.println("El ID debe ser mayor que 0. Animal no registrado.");
            return;
        }
        if (refugio.buscarPorId(id) != null) {
            System.out.println("Ya existe un animal con ese ID. Animal no registrado.");
            return;
        }

        String nombre = leerTexto("Nombre: ");
        if (nombre.isEmpty()) {
            System.out.println("El nombre no puede estar vacío. Animal no registrado.");
            return;
        }

        int edad = leerEntero("Edad: ");
        if (edad < 0) {
            System.out.println("La edad no puede ser negativa. Animal no registrado.");
            return;
        }

        try {
            Animal animal;
            if (tipo == 1) {
                String raza = leerTexto("Raza: ");
                animal = new Perro(id, nombre, edad, raza);
            } else {
                String color = leerTexto("Color: ");
                animal = new Gato(id, nombre, edad, color);
            }

            if (refugio.registrarAnimal(animal)) {
                System.out.println("Animal registrado correctamente con estado DISPONIBLE.");
            } else {
                System.out.println("No se pudo registrar el animal.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage() + " Animal no registrado.");
        }
    }

    private static void buscarAnimal(Refugio refugio) {
        if (refugio.estaVacio()) {
            System.out.println("No hay animales registrados en el refugio.");
            return;
        }
        int id = leerEntero("ID a buscar: ");
        Animal animal = refugio.buscarPorId(id);
        if (animal == null) {
            System.out.println("Animal no encontrado.");
        } else {
            animal.mostrarInformacion();
            System.out.println("Acción: " + animal.realizarAccion());
        }
    }

    private static void adoptarAnimal(Refugio refugio) {
        if (refugio.estaVacio()) {
            System.out.println("No hay animales registrados en el refugio.");
            return;
        }
        int id = leerEntero("ID del animal a adoptar: ");
        Animal animal = refugio.buscarPorId(id);

        if (animal == null) {
            System.out.println("Animal no encontrado.");
        } else if (animal.getEstado().equals("ADOPTADO")) {
            System.out.println("El animal ya está adoptado.");
        } else if (refugio.adoptarAnimal(id)) {
            System.out.println("¡" + animal.getNombre() + " fue adoptado! Estado: ADOPTADO.");
        }
    }
}
