package integracion;

public class Animal {


	    private int id;
	    private String nombre;
	    private int edad;
	    private String estado;

	    public Animal(int id, String nombre, int edad) {
	        if (id <= 0) {
	            throw new IllegalArgumentException("El ID debe ser mayor que 0.");
	        }
	        if (nombre == null || nombre.trim().isEmpty()) {
	            throw new IllegalArgumentException("El nombre no puede estar vacío.");
	        }
	        if (edad < 0) {
	            throw new IllegalArgumentException("La edad debe ser mayor o igual a 0.");
	        }
	        this.id = id;
	        this.nombre = nombre.trim();
	        this.edad = edad;
	        this.estado = "DISPONIBLE";
	    }

	    public int getId() {
	        return id;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	    public int getEdad() {
	        return edad;
	    }

	    public String getEstado() {
	        return estado;
	    }

	    // Único setter: solo se puede cambiar el estado
	    public void setEstado(String estado) {
	        this.estado = estado;
	    }

	    public void mostrarInformacion() {
	        System.out.println("ID: " + id);
	        System.out.println("Nombre: " + nombre);
	        System.out.println("Edad: " + edad + " año(s)");
	        System.out.println("Estado: " + estado);
	    }

	    public String realizarAccion() {
	        return "El animal hace un sonido.";
	    }
	}

