package Proyectomini;

import java.util.ArrayList;
import java.util.Scanner;


		public class Main {

		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);
		        ArrayList<Personaje> personajes = new ArrayList<>();
		        int opcion = 0;

		        do {
		            System.out.println("\n========== MENÚ ==========");
		            System.out.println("1. Registrar personaje");
		            System.out.println("2. Mostrar personajes");
		            System.out.println("3. Buscar personaje por id");
		            System.out.println("4. Salir");
		            System.out.print("Seleccione una opción: ");

		            try {
		                opcion = Integer.parseInt(sc.nextLine().trim()); 
		            } catch (NumberFormatException e) {
		                System.out.println("Error: debes ingresar un número.");
		                opcion = 0;
		                continue;
		            }

		            switch (opcion) {
		                case 1:
		                    registrarPersonaje(sc, personajes);
		                    break;
		                case 2:
		                    mostrarPersonajes(personajes);
		                    break;
		                case 3:
		                    buscarPersonaje(sc, personajes);
		                    break;
		                case 4:
		                    System.out.println("Saliendo del programa...");
		                    break;
		                default:
		                    System.out.println("Opción inválida. Elige entre 1 y 4.");
		            }
		        } while (opcion != 4);

		        sc.close();
		    }

		    private static void registrarPersonaje(Scanner sc, ArrayList<Personaje> personajes) {
		        try {
		            System.out.print("Tipo (1 = Guerrero, 2 = Mago): ");
		            int tipo = Integer.parseInt(sc.nextLine().trim());
		            if (tipo != 1 && tipo != 2) {
		                System.out.println("Tipo inválido. No se registró el personaje.");
		                return;
		            }

		            System.out.print("Id: ");
		            int id = Integer.parseInt(sc.nextLine().trim());
		            if (id <= 0) {
		                System.out.println("El id debe ser mayor que 0. No se registró el personaje.");
		                return;
		            }

		            System.out.print("Nombre: ");
		            String nombre = sc.nextLine().trim();
		            if (nombre.isEmpty()) {
		                System.out.println("El nombre no puede estar vacío. No se registró el personaje.");
		                return;
		            }

		            System.out.print("Nivel (1-100): ");
		            int nivel = Integer.parseInt(sc.nextLine().trim());
		            if (nivel < 1 || nivel > 100) {
		                System.out.println("El nivel debe estar entre 1 y 100. No se registró el personaje.");
		                return;
		            }

		            Personaje p;
		            if (tipo == 1) {
		                p = new Guerrero(id, nombre, nivel);
		            } else {
		                p = new mago(id, nombre, nivel);
		            }
		            personajes.add(p);
		            System.out.println("Personaje registrado correctamente.");

		        } catch (NumberFormatException e) {
		            System.out.println("Error: se esperaba un número. No se registró el personaje.");
		        }
		    }

		    private static void mostrarPersonajes(ArrayList<Personaje> personajes) {
		        if (personajes.isEmpty()) {
		            System.out.println("No hay personajes registrados.");
		            return;
		        }
		        for (Personaje p : personajes) {
		            p.mostrarInfo();
		            System.out.println("Acción: " + p.realizarAccion());
		            System.out.println("--------------------");
		        }
		    }

		    private static void buscarPersonaje(Scanner sc, ArrayList<Personaje> personajes) {
		        if (personajes.isEmpty()) {
		            System.out.println("No hay personajes registrados.");
		            return;
		        }
		        try {
		            System.out.print("Id a buscar: ");
		            int idBuscado = Integer.parseInt(sc.nextLine().trim());

		            Personaje encontrado = null;
		            for (Personaje p : personajes) {
		                if (p.getId() == idBuscado) {
		                    encontrado = p;
		                    break;
		                }
		            }

		            if (encontrado != null) {
		                encontrado.mostrarInfo();
		                System.out.println("Acción: " + encontrado.realizarAccion());
		            } else {
		                System.out.println("Personaje no encontrado");
		            }
		        } catch (NumberFormatException e) {
		            System.out.println("Error: el id debe ser un número.");
		        }
		    }
		}

	


