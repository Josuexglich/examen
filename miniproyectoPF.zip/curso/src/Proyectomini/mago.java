package Proyectomini;



	public class mago extends Personaje {

	    public mago(int id, String nombre, int nivel) {
	        super(id, nombre, nivel);
	    }

	    @Override
	    public String realizarAccion() {
	        return getNombre() + " el Mago lanza un hechizo de fuego.";
	    }
	}

