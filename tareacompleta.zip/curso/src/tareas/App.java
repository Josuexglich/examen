package tareas;


public class App {

    public static void main(String[] args) {
        Mascota mascota1 = new Mascota("Firulais", "Perro", 3);
        Mascota mascota2 = new Mascota("Michi", "Gato", 2);

        System.out.println("=== Mascota 1 ===");
        mascota1.mostrarInfo();

        System.out.println();

        System.out.println("=== Mascota 2 ===");
        mascota2.mostrarInfo();
    }
}
